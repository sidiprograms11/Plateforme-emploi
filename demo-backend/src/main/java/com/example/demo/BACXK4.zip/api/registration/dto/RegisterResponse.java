package com.example.demo.api.registration.dto;

import com.example.demo.identity.UserStatus;

public class RegisterResponse {

    private String id;
    private String email;
    private String role;
    private UserStatus status;

    public RegisterResponse(String id, String email, String role, UserStatus status) {
        this.id = id;
        this.email = email;
        this.role = role;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public UserStatus getStatus() {
        return status;
    }
}
