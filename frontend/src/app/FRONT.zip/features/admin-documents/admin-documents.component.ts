import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminDocumentService } from '../../services/admin-document.service';

@Component({
  selector: 'app-admin-documents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-documents.component.html',
  styleUrls: ['./admin-documents.component.css']
})
export class AdminDocumentsComponent {

  userId!: number;
  adminId!: number;
  documents: any[] = [];

  constructor(private adminDocService: AdminDocumentService) {}

  loadDocuments() {
    this.adminDocService.getUserDocuments(this.userId)
      .subscribe(res => {
        this.documents = res;
      });
  }

  download(docId: number) {
    this.adminDocService.downloadDocument(docId, this.adminId)
      .subscribe(blob => {
        const url = window.URL.createObjectURL(blob);
        window.open(url);
      });
  }
}