import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-identity-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './identity-list.component.html',
  styleUrls: ['./identity-list.component.css']
})
export class IdentityListComponent implements OnInit {

  users: any[] = [];
  selectedUser: any = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loadPending();
  }

  loadPending() {
    this.http.get<any[]>('http://localhost:8080/api/admin/identity/pending')
      .subscribe(res => this.users = res);
  }

  openModal(user: any) {
    this.selectedUser = user;
  }

  closeModal() {
    this.selectedUser = null;
  }

  approve(userId: string) {
    this.http.post(
      'http://localhost:8080/api/admin/identity/' + userId + '/approve',
      {},
      { responseType: 'text' }
    ).subscribe(() => {
      this.closeModal();
      this.loadPending();
    });
  }

  reject(userId: string) {
    this.http.post(
      'http://localhost:8080/api/admin/identity/' + userId + '/reject',
      {},
      { responseType: 'text' }
    ).subscribe(() => {
      this.closeModal();
      this.loadPending();
    });
  }

  getStatusClass(status: string) {
    if (status === 'PENDING_VERIFICATION') return 'status-pending';
    if (status === 'VERIFIED') return 'status-approved';
    if (status === 'REJECTED') return 'status-rejected';
    return '';
  }
}