import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h1>📊 Tableau de bord</h1>

    <div class="cards">

      <div class="card">
        <h3>Offres</h3>
        <p>{{ offersCount }}</p>
      </div>

      <div class="card">
        <h3>Candidatures</h3>
        <p>{{ applicationsCount }}</p>
      </div>

      <div class="card">
        <h3>Identités en attente</h3>
        <p>{{ pendingIdentities }}</p>
      </div>

    </div>
  `,
  styles: [`
    .cards {
      display: flex;
      gap: 20px;
      margin-top: 30px;
    }

    .card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      flex: 1;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    .card h3 {
      margin-bottom: 10px;
    }

    .card p {
      font-size: 28px;
      font-weight: bold;
      color: #2563eb;
    }
  `]
})
export class AdminDashboardComponent implements OnInit {

  offersCount = 0;
  applicationsCount = 0;
  pendingIdentities = 0;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {

    // Nombre d'offres
    this.http.get<any[]>('http://localhost:8080/api/offers')
      .subscribe(res => this.offersCount = res.length);

    // Identités en attente
    this.http.get<any[]>('http://localhost:8080/api/admin/identity/pending')
      .subscribe(res => this.pendingIdentities = res.length);

    // ⚠️ Pour les candidatures, on simplifie (à améliorer plus tard)
    this.applicationsCount = 0;
  }
}