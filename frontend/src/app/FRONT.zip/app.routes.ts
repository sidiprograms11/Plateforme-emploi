import { Routes } from '@angular/router';
import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [

  // ROOT
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  {
    path: 'login',
    loadComponent: () =>
      import('./login/login.component')
        .then(m => m.LoginComponent)
  },

  {
    path: 'register',
    loadComponent: () =>
      import('./register/register.component')
        .then(m => m.RegisterComponent)
  },

  // ===============================
  // USER AREA
  // ===============================
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./features/user/user-layout/user-layout')
        .then(m => m.UserLayout),

    children: [

      {
        path: 'coffre',
        loadComponent: () =>
          import('./features/user/coffre/coffre')
            .then(m => m.CoffreComponent)
      },

      {
        path: 'offers',
        loadComponent: () =>
          import('./features/offers/offers.component')
            .then(m => m.OffersComponent)
      },

     {
  path: 'upload',
  loadComponent: () =>
    import('./features/user/uploadfile/uploadfile')
      .then(m => m.UploadComponent)
},

      {
        path: '',
        redirectTo: 'coffre',
        pathMatch: 'full'
      }

    ]
  },

  // ===============================
  // ADMIN
  // ===============================
  {
    path: 'admin',
    canActivate: [AdminGuard],
    loadComponent: () =>
      import('./features/admin/admin-layout/admin-layout.component')
        .then(m => m.AdminLayoutComponent)
  },

  // FALLBACK
  { path: '**', redirectTo: 'login' }

];